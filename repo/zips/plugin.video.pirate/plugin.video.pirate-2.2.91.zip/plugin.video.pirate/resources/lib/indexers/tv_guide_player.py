"""Single-owner playback lifecycle for programs launched from the guide."""
from threading import Event
from uuid import uuid4

from modules import kodi_utils as ku
from modules.player import FenLightPlayer
from modules.sources import Sources


class GuideSources(Sources):
	def _make_progress_dialog(self):
		from windows.base_window import create_window
		self.progress_dialog = create_window(('windows.sources', 'SourcesPlayback'), 'sources_playback.xml', meta=self.meta)
		# show() returns with the dialog open. The same invocation can now close
		# it without racing a worker entering doModal() or waiting for it to exit.
		if self.progress_dialog is None:
			raise RuntimeError('Could not create the guide playback dialog')
		self.progress_dialog.show()

	def _kill_progress_dialog(self):
		dialog = self.progress_dialog
		self.progress_dialog = None
		if dialog:
			dialog.close()
			dialog.clearProperties()
			dialog.clear_modals()

	def playback_prep(self, params=None):
		try:
			return super().playback_prep(params)
		finally:
			self._kill_progress_dialog()


class GuidePlayer(FenLightPlayer):
	owner_key = 'fenlight.tvguide.playback_owner'

	def __init__(self):
		self._ended = Event()
		self._failed = False
		self._closed = False
		self._stop_sent = False
		self._owner = uuid4().hex
		super().__init__()

	def run(self, url=None, obj=None):
		ku.set_property(self.owner_key, self._owner)
		try:
			return super().run(url, obj)
		finally:
			self._closed = True
			self._ended.set()
			if self._owns_session():
				self.clear_playback_properties()
				ku.clear_property(self.owner_key)
			self.sources_object = None

	def _owns_session(self):
		return ku.get_property(self.owner_key) == self._owner

	def clear_playback_properties(self):
		if self._owns_session():
			super().clear_playback_properties()

	def onPlayBackStopped(self):
		self._ended.set()

	def onPlayBackEnded(self):
		self._ended.set()

	def onPlayBackError(self):
		self._failed = True
		self._ended.set()

	def stop(self):
		if self._closed or self._stop_sent or self._ended.is_set() or not self._owns_session():
			return
		self._stop_sent = True
		super().stop()

	def playback_interrupted(self):
		return self._ended.is_set() or not self._owns_session() or self.kodi_monitor.abortRequested()

	def wait_for_sample(self):
		return not self._ended.wait(1) and not self.playback_interrupted() and self.isPlayingVideo()

	def check_playback_start(self):
		super().check_playback_start()
		if self._failed and self._owns_session():
			self.cancel_all_playback = False
			self.playback_successful = False
		if self.playback_successful:
			self.sources_object.playback_successful = True
			from indexers.tv_guide_guard import playback_started
			playback_started()
			self.playback_started()

	def playback_started(self):
		pass

	def playback_close_dialogs(self):
		self.sources_object.playback_successful = True
		self.kill_dialog()

	def kill_dialog(self):
		if self.sources_object:
			self.sources_object._kill_progress_dialog()

	def dispatch_progress(self, function, params):
		# Already on the plug-in invocation thread. Finish its bookmark/watch
		# update before Kodi releases this interpreter and its Player wrapper.
		if self._owns_session() and not self.kodi_monitor.abortRequested():
			self.run_media_progress(function, params)

	def make_listing(self):
		item = super().make_listing()
		logo = self.sources_object.params.get('tv_guide_channel_logo')
		if logo:
			item.setArt({'pirate_channel_logo': logo})
		return item
