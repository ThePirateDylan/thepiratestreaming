"""Editorial catalog and exact-item eligibility; no GUI or player ownership."""
import hashlib
import json
import re
import unicodedata
from datetime import datetime
from time import time
from urllib.parse import quote_plus

VERIFIED = ('verified-source', 'playback-verified')
ALIASES = {"The Paw Patrol Movie": "PAW Patrol: The Movie", "Pokémon: The First Movie": "Pokémon: The First Movie - Mewtwo Strikes Back", "The Wonder Pets!": "Wonder Pets!", "The Great British Bake Off": "The Great British Baking Show"}


def canonical(text):
    return ''.join(c for c in unicodedata.normalize('NFKD', str(text)).casefold() if c.isalnum())


def specification(title):
    match = re.search(r' \((\d{4}|US|UK)\)$', title)
    qualifier = match.group(1) if match else ''
    name = title[:match.start()] if match else title
    return name, qualifier


def select_match(title, results, movie=False):
    name, qualifier = specification(title)
    expected = {canonical(name), canonical(ALIASES.get(name, name))}
    matches = []
    for result in results:
        names = {canonical(result.get(k, '')) for k in ('title', 'name', 'original_title', 'original_name')}
        # TMDb sometimes retains the edition in the display name.
        names.update(canonical(specification(result.get(k, ''))[0]) for k in ('title', 'name'))
        if not expected.intersection(names): continue
        year = str(result.get('release_date' if movie else 'first_air_date', ''))[:4]
        if qualifier.isdigit() and year != qualifier: continue
        if qualifier in ('US', 'UK') and ('GB' if qualifier == 'UK' else 'US') not in result.get('origin_country', []): continue
        matches.append(result)
    # A remake/edition ambiguity needs a year, never the first popularity result.
    ids = {str(r['id']) for r in matches if r.get('id')}
    return matches[0] if len(ids) == 1 else None


def source_context():
    from modules import settings
    return {'providers': sorted(settings.active_internal_scrapers()),
            'episode_quality': settings.quality_filter('autoplay_quality_episode'),
            'movie_quality': settings.quality_filter('%s_quality_movie' % ('autoplay' if settings.auto_play('movie') else 'results')),
            'playback': settings.playback_key()}


def exact_key(program):
    media = program.get('media_type')
    season = program.get('_guide_season', program.get('season'))
    episode = program.get('_guide_episode', program.get('episode'))
    if media in ('tvshow', 'episode') and (season is None or episode is None):
        return None
    data = {'context': source_context(), 'media': 'movie' if media == 'movie' else 'episode',
            'id': str(program['tmdb_id']), 'season': int(season) if season is not None else None, 'episode': int(episode) if episode is not None else None,
            'release': program.get('_guide_release', '')}
    return 'guide_exact_v2_' + hashlib.sha256(json.dumps(data, sort_keys=True, default=str).encode()).hexdigest()


def outcome(program, cache, now=None):
    key = exact_key(program)
    record = cache.get(key) if key else None
    if isinstance(record, dict) and record.get('until', 0) > (time() if now is None else now):
        return record['status']
    return 'unverified'


def record(program, status, cache):
    key = exact_key(program)
    if not key: return
    hours = 168 if status == 'playback-verified' else 6 if status == 'verified-source' else 1/6
    cache.set(key, {'status': status, 'at': time(), 'until': time()+hours*3600}, expiration=hours)


def candidates(channel, api, make_record, icon):
    """Bounded metadata work, called only by the existing catalog worker."""
    from modules import kodi_utils, metadata, settings
    from modules.utils import get_datetime
    programs = []
    for media, field in [('tvshow','tv_candidate_titles'), ('movie','movie_candidate_titles'), ('tvshow','hold_candidate_titles')]:
        for title in channel.get(field, ()):
            if kodi_utils.kodi_monitor().abortRequested(): raise InterruptedError('Guide catalog stopped')
            held = field == 'hold_candidate_titles'
            name, qualifier = specification(title)
            lookup = api.tmdb_movies_search if media == 'movie' else api.tmdb_tv_search
            try:
                result = select_match(title, (lookup(quote_plus(name),1) or {}).get('results',[]), media=='movie')
                if not result:
                    kodi_utils.logger('TV Guide catalog', 'channel=%s unmatched=%s' % (channel['id'],title))
                    continue
                p = make_record(result, media, icon)
                if not p: continue
                p.update(_editorial_title=title, _hold=held, source_status='unverified')
                meta_func = metadata.movie_meta if media=='movie' else metadata.tvshow_meta
                meta = meta_func('tmdb_id', p['tmdb_id'],settings.tmdb_api_key(), settings.mpaa_region(),get_datetime())
                if not meta or meta.get('blank_entry'): continue
                p['_guide_mpaa'] = meta.get('mpaa') or ''
                p['_guide_release'] = str(meta.get('year') or '')
                if media=='movie':
                    p['duration_minutes'] = max(1, int((meta.get('duration') or 6600)/60))
                else:
                    # Two seasons per series/pass; rotate historical seasons daily.
                    # No all-season thread fan-out or episode probing on guide open.
                    seasons = sorted({int(s['season_number']) for s in meta.get('season_data',[]) if int(s.get('season_number',0))>0})
                    if not seasons: continue
                    selected = sorted({seasons[-1],seasons[datetime.now().date().toordinal()%len(seasons)]})
                    episodes = []
                    for season in selected:
                        if kodi_utils.kodi_monitor().abortRequested(): raise InterruptedError('Guide catalog stopped')
                        for ep in metadata.episodes_meta(season,meta) or []:
                            aired = ep.get('premiered')
                            if not aired or aired > datetime.now().strftime('%Y-%m-%d'): continue
                            episodes.append(dict(_guide_season=ep['season'], _guide_episode=ep['episode'],
                                _guide_release='%s:%s:%s' % (meta.get('year',''),aired,ep.get('episode_id','')),
                                duration_minutes=max(1,int((ep.get('duration') or 1800)/60)),
                                episode_title=ep.get('title',''), premiered=aired))
                    p['_episodes'] = episodes[-160:]
                    if not episodes: continue
                programs.append(p)
            except InterruptedError: raise
            except Exception as exc:
                kodi_utils.logger('TV Guide catalog', 'channel=%s title=%s error=%s' % (channel['id'],title,type(exc).__name__))
    return programs


def eligible_pool(programs, cache):
    result = []
    for p in programs:
        p = dict(p)
        if p['media_type']=='movie':
            state = outcome(p,cache)
            if state=='miss' or (p.get('_hold') and state not in VERIFIED): continue
            p['source_status']=state
        else:
            episodes = []
            for ep in p.get('_episodes',[]):
                state = outcome(dict(p,**ep),cache)
                if state=='miss' or (p.get('_hold') and state not in VERIFIED): continue
                episodes.append(dict(ep,source_status=state))
            if p.get('_episodes') is not None:
                if not episodes: continue
                p['_episodes']=episodes
                p['duration_minutes']=max(ep['duration_minutes'] for ep in episodes)
            elif p.get('_hold'): continue
        result.append(p)
    return result


def assign_episode(program, slot, recent):
    if not program.get('_episodes'): return dict(program)
    from indexers.guide_rotation import seed
    def identity(e): return '%s:%s:%s' % (program['tmdb_id'], e['_guide_season'],e['_guide_episode'])
    pool=program['_episodes']
    def rank(e):
        key=identity(e)
        return (int(key not in recent[-50:]), -recent.count(key),int(e.get('source_status') in VERIFIED),seed(slot,key))
    ep=max(pool,key=rank)
    recent.append(identity(ep))
    p={k:v for k,v in program.items() if k!='_episodes'}
    p.update(ep)
    p['title'] = '%s — S%s E%s%s' % (program['title'],ep['_guide_season'],ep['_guide_episode'], ' · '+ep['episode_title'] if ep.get('episode_title') else '')
    return p
