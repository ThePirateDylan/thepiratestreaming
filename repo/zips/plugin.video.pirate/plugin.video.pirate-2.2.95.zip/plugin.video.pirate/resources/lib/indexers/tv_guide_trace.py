"""Temporary diagnostic. Never inspect frame locals, arguments or URLs."""
import sys
import threading

def event(name):
    try:
        import xbmc
        xbmc.log('[PirateGuideTrace] %s ident=%s native=%s' %
                 (name, threading.get_ident(), threading.get_native_id()), xbmc.LOGDEBUG)
    except Exception:
        pass  # Diagnostics must not interrupt callbacks or teardown.

def window_unloaded():
    event('guide-unload received')
    try:
        frames = sys._current_frames()
        try:
            matches = 0
            for ident, frame in frames.items():
                stack = []
                relevant = False
                while frame is not None and len(stack) < 100:
                    module = frame.f_globals.get('__name__', '')
                    func = frame.f_code.co_name
                    if (module.startswith(('indexers.tv_guide', 'indexers.food_netwurk',
                                           'scrapers.', 'cocoscrapers.', 'apis.'))
                            and module != __name__):
                        relevant = True
                    # Only static Python identifiers and line numbers are emitted.
                    module = '.'.join(x for x in module.split('.') if x.isidentifier())
                    stack.append('%s.%s:%s' % (module, func if func.isidentifier() else '?', frame.f_lineno))
                    frame = frame.f_back
                if relevant:
                    matches += 1
                    event('sample target_ident=%s stack=%s' % (ident, ' <- '.join(stack)))
            event('sample complete matches=%s' % matches)
        finally:
            frames.clear()
    except Exception:
        event('frame snapshot unavailable')
