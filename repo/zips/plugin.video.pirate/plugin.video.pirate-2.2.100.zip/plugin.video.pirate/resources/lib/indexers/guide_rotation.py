"""Cached guide programming. No player, GUI, scraping or background workers."""
import hashlib
import json
import math
from datetime import datetime, timedelta
from time import time


def seed(*parts):
    return int(hashlib.sha256('|'.join(map(str, parts)).encode('utf-8')).hexdigest()[:16], 16)


def identity(program):
    return '%s:%s' % (program['media_type'], program['tmdb_id'])


def daypart(hour):
    return 'daytime' if 6 <= hour < 17 else 'prime_time' if 17 <= hour < 23 else 'overnight'


def _minutes(program):
    try:
        minutes = float(program.get('duration_minutes', 0))
        if not 15 <= minutes <= 360:
            raise ValueError()
    except (TypeError, ValueError):
        minutes = 110 if program['media_type'] == 'movie' else 30
    return int(math.ceil(minutes / 30.0)) * 30


def build_day(programs, channel, day, recent=(), scores=None):
    """Half-hour broadcast blocks, with longer slots for longer programs."""
    scores = scores or {}
    pool = list({identity(p): p for p in programs}.values())
    if not pool:
        return []
    cursor = datetime.combine(day, datetime.min.time())
    limit = cursor + timedelta(days=1)
    anchors = {}
    if day.weekday() < 5:
        for clock, title in channel.get('weekday_anchors', {}).items():
            match = next((p for p in pool if p['title'].casefold() == title.casefold()), None)
            if match:
                hour, minute = map(int, clock.split(':'))
                anchors[cursor.replace(hour=hour, minute=minute)] = match
    counts, slots, history = {}, [], list(recent)[-24:]
    while cursor < limit:
        block = daypart(cursor.hour)
        deadline = min([t for t in anchors if t > cursor] + [limit])
        remaining = (deadline - cursor).total_seconds() / 60
        anchored = anchors.get(cursor)
        candidates = [p for p in pool if _minutes(p) <= remaining]
        if anchored:
            candidates = [anchored]
        if not candidates:
            # Keep the last broadcast on screen until the next fixed boundary;
            # never start a film that would be cut off by the next program.
            slots[-1]['end'] = deadline.isoformat()
            cursor = deadline
            continue
        preferred = channel.get('program_blocks', {}).get(block, ())
        def rank(p):
            key = identity(p)
            good, bad = scores.get(key, (0, 0))
            affinity = p['title'] in preferred if preferred else (
                p['media_type'] == ('movie' if block == 'prime_time' else 'tvshow'))
            # Variety wins over source history; success only breaks comparable
            # choices, so a previously playable show cannot monopolize a day.
            return (-counts.get(key, 0), -history[-max(1, min(len(pool)-1, 12)):].count(key),
                    int(affinity), (good + 1) / (good + bad + 2),
                    seed(channel['id'], day, block, cursor.hour, key))
        chosen = max(candidates, key=rank)
        length = min(30 if anchored else _minutes(chosen), remaining)
        end = cursor + timedelta(minutes=length)
        slots.append({'program': dict(chosen), 'start': cursor.isoformat(),
                      'end': end.isoformat(), 'daypart': block})
        key = identity(chosen)
        counts[key] = counts.get(key, 0) + 1
        history.append(key)
        cursor = end
    return slots


def schedule(programs, channel, now, count, cache):
    # Freeze each published day. A metadata refresh or reopening cannot shuffle
    # its slots; only a channel-definition change invalidates that day's plan.
    revision = hashlib.sha256(json.dumps(channel, sort_keys=True, default=str).encode()).hexdigest()[:16]
    def key(day):
        return 'guide_day_v1_%s_%s_%s' % (channel['id'], revision, day.isoformat())
    result = []
    day = now.date()
    for _ in range(3):
        slots = cache.get(key(day))
        if not slots:
            previous = cache.get(key(day - timedelta(days=1))) or []
            recent = [identity(s['program']) for s in previous]
            scores = cache.get('guide_rotation_scores_v1_' + channel['id']) or {}
            slots = build_day(programs, channel, day, recent, scores)
            # Keep visited past/future days through the supported guide range.
            cache.set(key(day), slots, expiration=24 * 80)
        for slot in slots:
            start, end = datetime.fromisoformat(slot['start']), datetime.fromisoformat(slot['end'])
            if end <= now:
                continue
            item = dict(slot, program=dict(slot['program']), start=start, end=end,
                        duration_minutes=int((end-start).total_seconds() // 60))
            item['program']['_rotation_slot'] = key(day) + '_' + slot['start']
            result.append(item)
            if len(result) >= count:
                return result
        day += timedelta(days=1)
    return result


def choose_episode(episodes, state, slot, now=None):
    """Choose from already-filtered aired episodes; no metadata or source calls."""
    now = time() if now is None else now
    choices = {'%s:%s' % (e['season'], e['episode']): e for e in episodes}
    outcomes = state.get('outcomes', {})
    choices = {key: e for key, e in choices.items()
               if not (outcomes.get(key, {}).get('status') == 'miss'
                       and outcomes[key].get('until', 0) > now)}
    if not choices:
        return None
    if state.get('slot') == slot and state.get('pick') in choices:
        return choices[state['pick']]
    history = state.get('recent', [])
    unused = {key: e for key, e in choices.items() if key not in history}
    pool = unused or choices
    def rank(key):
        last = max((i for i, v in enumerate(history) if v == key), default=-1)
        played = outcomes.get(key, {}).get('status') == 'played'
        return (-last, int(played), seed(slot, key))
    return pool[max(pool, key=rank)]


def episode_params(meta, channel_id, slot):
    """Retain random guide playback, with persisted per-channel episode history."""
    from caches.main_cache import main_cache
    from modules import metadata, settings
    from modules.utils import adjust_premiered_date, get_datetime
    from indexers.tv_guide import _source_check_cache_key
    context = _source_check_cache_key({'media_type': 'tvshow', 'tmdb_id': meta['tmdb_id']})
    state_key = 'guide_episode_v1_%s_%s' % (channel_id, context)
    state = main_cache.get(state_key) or {}
    current, offset = get_datetime(), settings.date_offset()
    aired = []
    for episode in metadata.all_episodes_meta(meta) or []:
        premiered = episode.get('premiered')
        if not premiered:
            continue
        date = adjust_premiered_date(premiered, offset)[0]
        if date and date <= current:
            aired.append(episode)
    # Direct catalog tuning has no broadcast slot and intentionally picks afresh.
    slot = slot or str(time())
    chosen = choose_episode(aired, state, slot)
    if not chosen:
        return None
    state.update(slot=slot, pick='%s:%s' % (chosen['season'], chosen['episode']))
    main_cache.set(state_key, state, expiration=24 * 30)
    playback_key = settings.playback_key()
    return {'media_type': 'episode', 'tmdb_id': str(meta['tmdb_id']),
            'season': int(chosen['season']), 'episode': int(chosen['episode']),
            'random': 'true', 'autoplay': 'true', playback_key: playback_key,
            '_guide_history_key': state_key, '_guide_channel': channel_id}


def movie_key(program):
    from indexers.tv_guide import _source_check_cache_key
    return 'guide_movie_outcome_v1_' + _source_check_cache_key(program)


def available_movie(program, programs, cache, slot):
    """Replace a known movie miss with a fitting film from the same channel."""
    def status(p):
        return cache.get(movie_key(p))
    if program['media_type'] != 'movie' or status(program) != 'miss':
        return program
    minutes = (slot['end'] - slot['start']).total_seconds() / 60
    choices = [p for p in programs if p['media_type'] == 'movie'
               and _minutes(p) <= minutes and status(p) != 'miss']
    if not choices:
        return None
    choice = max(choices, key=lambda p: (status(p) == 'played', seed(program['_rotation_slot'], identity(p))))
    day_key, start = program['_rotation_slot'].rsplit('_', 1)
    slots = cache.get(day_key) or []
    for row in slots:
        if row['start'] == start:
            row['program'] = dict(choice)
    cache.set(day_key, slots, expiration=24 * 80)
    return dict(choice, _rotation_slot=program['_rotation_slot'])


def remember(params, success):
    from caches.main_cache import main_cache
    now = time()
    if params['media_type'] == 'movie':
        main_cache.set(movie_key(params), 'played' if success else 'miss', expiration=168 if success else 1/6)
    state_key = params.get('_guide_history_key')
    if state_key:
        state = main_cache.get(state_key) or {}
        pick = '%s:%s' % (params['season'], params['episode'])
        outcomes = {k: v for k, v in state.get('outcomes', {}).items() if v.get('until', 0) > now}
        outcomes[pick] = {'status': 'played' if success else 'miss', 'until': now + (7*86400 if success else 600)}
        # Bound persisted state on long-running daily series.
        state['outcomes'] = dict(sorted(outcomes.items(), key=lambda x: x[1]['until'])[-200:])
        if success:
            state['recent'] = (state.get('recent', []) + [pick])[-50:]
        else:
            state.pop('pick', None)
        main_cache.set(state_key, state, expiration=24 * 30)
    channel = params.get('_guide_channel')
    if channel:
        score_key = 'guide_rotation_scores_v1_' + channel
        scores = main_cache.get(score_key) or {}
        key = '%s:%s' % ('tvshow' if params['media_type'] == 'episode' else 'movie', params['tmdb_id'])
        good, bad = scores.get(key, (0, 0))
        scores[key] = (good * .95 + int(success), bad * .95 + int(not success))
        main_cache.set(score_key, scores, expiration=24 * 30)
